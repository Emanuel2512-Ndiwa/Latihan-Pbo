package UAS.UAS_PBO_123;




import java.util.ArrayList;
import java.util.List;;

public class mainProgram {
    public static void main(String[] args) {
        pasien p1 = new pasien("235314189", "MARIO FENERIAL LETA BILLI");
        terapis t1 = new terapis("Sertifikat FISIOTERAPI", "ALLAN SODHO");
        terapis t2 = new terapis("Sertifikat Fisioterapis", "FANES BATE");
        karyawan admin = new administrasi("235314144", "AGNES VIVIAN MUJA", "Sertifikat FISIOTERAPI");
        jasaTerapi jt1 = new jasaTerapi("Saraf", 300_000, t1);
        jasaTerapi jt2 = new jasaTerapi("ortopedi", 200_000, t2);
        jasaTerapi jt3 = new jasaTerapi("geriati", 75_000, t2);
        List<jasaTerapi> jasa = new ArrayList<>();
        jasa.add(jt1);
        jasa.add(jt2);
        jasa.add(jt3);

        perawatan pr1 = new perawatan("id-rawat-1", p1, admin, jasa, jasa);
        System.out.println();
        System.out.println("Klinik Bang Tirex ==> 123");
        System.out.println();
        System.out.println("-------------------------------------------------------------");
        System.out.println("id Perawatan\t:" + pr1.getIdPerawatan());
        System.out.println(
                "Pelanggan\t:" + "Bpk/Ibu/Sdr" + pr1.getPasien().getNamaPasien() + "\tNomor Memeber\t"
                        + pr1.getPasien().getIdPasien());
        System.out.println("Kasir\t\t:" + pr1.getKasir().getNama() + "\tNik\t" + pr1.getKasir().getNik());
        System.out.println();
        System.out.println("[Biaya Perawatan Fisio Terapi]");
        pr1.totalBiaya();
       
        }
    }


