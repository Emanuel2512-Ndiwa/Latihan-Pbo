package UAS.UAS_PBO_123;

public class pasien {
    public String idPasien;
    public String namaPasien;

    public pasien(String idPasien, String namaPasien) {
        this.idPasien = idPasien;
        this.namaPasien = namaPasien;
    }

    public String getIdPasien() {
        return idPasien;
    }

    public String getNamaPasien() {
        return namaPasien;
    }

}
