package UAS.UAS_PBO_123;

public class administrasi extends karyawan {
    public String sertifikatKomputer;

    administrasi(String nik, String nama, String sertifikat) {
        super(nik, nama);
        this.sertifikatKomputer = sertifikat;
    }

    public String getSertifikatKomputer() {
        return sertifikatKomputer;
    }

}
