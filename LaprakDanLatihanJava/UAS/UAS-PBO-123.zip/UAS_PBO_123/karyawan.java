package UAS.UAS_PBO_123;

public class karyawan {
    public String nik;
    public String nama;

    public karyawan(String nik, String nama) {
        this.nik = nik;
        this.nama = nama;
    }

    public String getNik() {
        return nik;
    }

    public String getNama() {
        return nama;
    }

}
