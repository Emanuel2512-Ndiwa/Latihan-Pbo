package UAS.UAS_PBO_123;

public class jasaTerapi {
    public String jenisTerapi;
    public double tarif;
    public terapis terapi;

    public jasaTerapi(String jenisTerapi, double tarif, terapis terapi) {
        this.jenisTerapi = jenisTerapi;
        this.tarif = tarif;
        this.terapi = terapi;
    }

    public String getJenisTerapi() {
        return jenisTerapi;
    }

    public double getTarif() {
        return tarif;
    }

    public terapis getTerapi() {
        return terapi;
    }

}
